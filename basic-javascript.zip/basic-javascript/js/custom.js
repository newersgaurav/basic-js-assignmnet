function startTime() {
  var today = new Date();

  var month = ["JANUARY","FEBRAURY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"];
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  var d = today.getDate();
  var mn = today.getMonth();
  var mn1 = month[mn];
  var y = today.getFullYear();

  if(h >= 0 && h < 12){
    var meridiem = "AM";
  }
  else{
    var meridiem = "PM";
  }

  var wish = findWish(h);

  m = checkTime(m);
  s = checkTime(s);
  h = checkTime(checkHours(h));

  document.getElementById('wish').innerHTML = wish;

  document.getElementById('time').innerHTML =
  h + ":" + m + ":" + s + "  " + meridiem;

  document.getElementById('date').innerHTML = d + " " + mn1 + " " + y;

  var t = setTimeout(startTime, 500);
}
function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}

function checkHours(h){
  if(h > 12){
    h = h-12;
  }
  if(h == 0){
    h = 12;
  }
  return h;
}

function findWish(h) {
  var wish;
  if(h >= 5 && h < 12){
    wish = "Good Morning";
  }
  else if(h >= 12 && h < 17){
    wish = "Good Afternoon";
  }
  else{
    wish = "Good Evening";
  }

  return wish;
}